package com;

public class Department {

	private int did;

	private String departmentName;

	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	@Override
	public String toString() {
		return "Department [did=" + did + ", departmentName=" + departmentName + "]";
	}

}
