package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Controller {

	public static void main(String[] args) {

//		Container -> Reads Config File , creates Beans  , Maintains life cycle of bean , Destroy.
//		beanFactory -> It is a Core Container.
//		               it cant able to  read config file directly , -> helps Resource(I)

//		Resource resource = new ClassPathResource("beans.xml");
//		
//		BeanFactory bf = new XmlBeanFactory(resource);
//		
//		Student student = bf.getBean("st",Student.class);

//		ApplicationContext -> It is a J2ee Container , Reads Multiple config files , Eager Loader

//		Scopes -> Definning after callng get bean method how you want to create your object
//		1. singelton -> Bydefault -> Singel Object
//		2. prototype -> diff object
//		3. request   -> every httptrequest -> new object 
//		4. session   -> every httpsession -> new Object
		
		ApplicationContext apc = new ClassPathXmlApplicationContext("beans.xml");
		Student student1 = apc.getBean("st", Student.class);
//		Student student2 = apc.getBean("st",Student.class);
//		Student student3 = apc.getBean("st",Student.class);
		System.out.println(student1);
//		System.out.println(student2.hashCode());
//		System.out.println(student3.hashCode());
		
//		Project
//		course -> faculty -> batch -> student

	}
}
