package com;

import java.util.InputMismatchException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Entity.User;
import com.Exception.NameisNullException;

@Controller
public class HomeController {

	// class level Handling ->

//	@ExceptionHandler(value = NullPointerException.class)
//	public String handleNullpointer() {
//
//		// exception handling execute.
//
//		System.out.println("---100 line of code---");
//		System.out.println("Class level handling");
//		return "error";
//
//	}

	@RequestMapping("/log")
	public String getLogRequest(@RequestParam("un") String username, @RequestParam("ps") String password) {
		System.out.println("this is log request");
		System.out.println("UserName  :: " + username);
		System.out.println("Password :: " + password);
//		model -> data (map) and view -> web page name
		String name = null;
//		System.out.println(name.toLowerCase());

		if (name == null) {
			throw new NameisNullException("Name is null");
		}

		return "success";
	}

	@RequestMapping("/reg")
	public String registerUser(@ModelAttribute User user, Model model) {
		System.out.println("All Register Data :: " + user);
		model.addAttribute("msg", user);

		return "Login";
	}

}
