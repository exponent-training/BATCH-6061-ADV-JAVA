package com.Exception;

public class NameisNullException extends RuntimeException {

	public NameisNullException(String msg) {
		super(msg);
	}
}
