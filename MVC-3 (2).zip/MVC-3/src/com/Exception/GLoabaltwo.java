package com.Exception;

import org.springframework.core.annotation.Order;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

//@ControllerAdvice
//@Order(1)
public class GLoabaltwo {

	@ExceptionHandler(value = NullPointerException.class)
	public String handleNullpointer(NullPointerException msg) {

		// exception handling execute.
		msg.printStackTrace();
		System.out.println(msg.getMessage());
		System.out.println("---100 line of code---");
		System.out.println("Global Handling");
		return "error";

	}
}
