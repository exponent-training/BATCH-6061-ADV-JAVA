package com.Config;

import java.util.Properties;

import org.hibernate.cfg.Environment;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
public class Appconfig {

	@Bean
	public InternalResourceViewResolver viewResolver() {
		InternalResourceViewResolver irv = new InternalResourceViewResolver();
		irv.setSuffix(".jsp");

		return irv;
	}

	@Bean
	public DriverManagerDataSource dataSource() {

		DriverManagerDataSource ds = new DriverManagerDataSource();
		ds.setDriverClassName("com.mysql.jdbc.Driver");
		ds.setUrl("jdbc:mysql://localhost:3306/batch6061");
		ds.setUsername("root");
		ds.setPassword("root");

		return ds;

	}

	@Bean
	public LocalSessionFactoryBean getSessionFactory() {
		LocalSessionFactoryBean lsf = new LocalSessionFactoryBean();
		lsf.setDataSource(dataSource());

		Properties prop = new Properties();
		prop.setProperty(Environment.DIALECT, "org.hibernate.dialect.MySQLDialect");
		prop.setProperty(Environment.HBM2DDL_AUTO, "update");
		prop.setProperty(Environment.SHOW_SQL, "true");

//		lsf.setAnnotatedClasses();

		return lsf;
	}

}
