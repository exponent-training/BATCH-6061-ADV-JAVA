package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Controller {

	
	public static void main(String[] args) {
		
//		Container -> Reads Config File , creates Beans  , Maintains life cycle of bean , Destroy.
//		beanFactory -> It is a Core Container.
//		               it cant able to  read config file directly , -> helps Resource(I)
		
//		Resource resource = new ClassPathResource("beans.xml");
//		
//		BeanFactory bf = new XmlBeanFactory(resource);
//		
//		Student student = bf.getBean("st",Student.class);
		
//		ApplicationContext -> It is a J2ee Container , Reads Multiple config files , Eager Loader
//		
		ApplicationContext apc = new ClassPathXmlApplicationContext("beans.xml");
//		Student student = apc.getBean("st",Student.class);
	
		
		
		
		
		
		
		
		
	}
}
