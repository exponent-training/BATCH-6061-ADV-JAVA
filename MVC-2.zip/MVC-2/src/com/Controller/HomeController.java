package com.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

	@RequestMapping("/log")
	public void getLogrequest()
	{
		System.out.println("This is log Request");
	}
}
