package com;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Entity.User;

@Controller
public class HomeController {

	@RequestMapping("/log")
	public String getLogRequest(@RequestParam("un") String username, @RequestParam("ps") String password) {
		System.out.println("this is log request");
		System.out.println("UserName  :: " + username);
		System.out.println("Password :: " + password);
//		model -> data (map) and view -> web page name

		return "success";
	}

	@RequestMapping("/reg")
	public String registerUser(@ModelAttribute User user,Model model) {
		System.out.println("All Register Data :: " + user);
		model.addAttribute("msg", user);
		
		return "Login";
	}

}
