package com.Entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Student {

	private int stuid;

	private String sname;

	private String saddress;

	@Autowired
//	@Qualifier(value = "schoolName")
	private School sch;

	public School getSch() {
		return sch;
	}

	public void setSch(School sch) {
		this.sch = sch;
	}

	public int getStuid() {
		return stuid;
	}

	public void setStuid(int stuid) {
		this.stuid = stuid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSaddress() {
		return saddress;
	}

	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}

	@Override
	public String toString() {
		return "Student [stuid=" + stuid + ", sname=" + sname + ", saddress=" + saddress + ", sch=" + sch + "]";
	}

}
