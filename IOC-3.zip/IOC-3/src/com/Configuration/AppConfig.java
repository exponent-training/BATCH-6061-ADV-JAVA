package com.Configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;

import com.Entity.School;
import com.Entity.Student;

@Configuration
public class AppConfig {

	@Bean(name = "stu")
	public Student getStudent() {
		Student st = new Student();
		st.setStuid(101);
		st.setSname("raj");
		st.setSaddress("PUNE");
		return st;
	}

	@Bean(name = "sc1")
	@Primary
	public School getSchool1() {
		School sch = new School();
		sch.setSchoolId(1001);
		sch.setSchoolName("XYZ");
		return sch;
	}

	@Bean(name = "sc2")
	public School getSchool2() {
		School sch = new School();
		sch.setSchoolId(1002);
		sch.setSchoolName("ABC");
		return sch;
	}

}
