package com.Controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.Configuration.AppConfig;
import com.Entity.Student;

public class HomeController {

	public static void main(String[] args) {

//		new ClassPathXmlApplicationContext(); -> XML
		ApplicationContext apc = new AnnotationConfigApplicationContext(AppConfig.class); // -> Anotaion Based.
		Student st = apc.getBean("stu", Student.class);
		System.out.println(st);
		
//		connection bean -5 , 1) Mysql , 2) Postgres , 3) oracle.
	}
}
