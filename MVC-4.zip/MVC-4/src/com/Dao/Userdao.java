package com.Dao;

import com.Model.User;

public interface Userdao {

	public void signUpdao(User user);
	
}
