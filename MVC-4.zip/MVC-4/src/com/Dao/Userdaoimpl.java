package com.Dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Model.User;

@Repository
public class Userdaoimpl implements Userdao {

	@Autowired
	private SessionFactory sf;

	@Override
	public void signUpdao(User user) {

		System.out.println("I am in Dao Layer :: " + user);

		Session session = sf.openSession();

		session.save(user);
		session.beginTransaction().commit();
		System.out.println("User saved");

		// db -persist
	}

}
