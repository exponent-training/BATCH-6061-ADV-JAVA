package com.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Dao.Userdao;
import com.Model.User;

@Service
public class Userserviceimpl implements UserService {

	@Autowired
	private Userdao ud;
	
	
	@Override
	public void signUpUser(User user) {

		System.out.println("I am in Service layer ::" + user);
		
		ud.signUpdao(user);
		
	}
}
