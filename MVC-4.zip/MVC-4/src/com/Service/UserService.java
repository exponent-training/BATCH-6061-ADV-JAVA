package com.Service;

import com.Model.User;

public interface UserService {

	public void signUpUser(User user);

}
