package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.Model.User;
import com.Service.UserService;

@Controller
public class HomeController {

	@Autowired
	private UserService us;

	@RequestMapping("/reg")
	public String signUp(@ModelAttribute User user) {
		System.out.println("I am in Controller  : " + user);

		us.signUpUser(user);

		return "Login";
	}
}
