package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import com.Model.User;
import com.Service.UserService;

@Controller
public class HomeController {

	@Autowired
	private UserService us;

	@RequestMapping("/reg")
	public String signUp(@ModelAttribute User user) {
		System.out.println("I am in Controller  : " + user);

		us.signUpUser(user);

		return "Login";
	}

	@RequestMapping("/log")
	public String signIn(@RequestParam("un") String username, @RequestParam("ps") String password, Model model) {
		System.out.println("I am in Controller : " + username + " " + password);

		User user = us.sigInUser(username, password);
		if (user != null) {
			model.addAttribute("msg", user);
			return "success";
		}

		model.addAttribute("msg", "Credentials invalid");
		return "Login";

	}
	
	
	@RequestMapping("/file")
	public String uploadFiles(@RequestPart MultipartFile file) {
		
		System.out.println("I am in Controller Layer");
		
		us.uploadFileInService(file);
		
		return "Login";
		
	}

}
