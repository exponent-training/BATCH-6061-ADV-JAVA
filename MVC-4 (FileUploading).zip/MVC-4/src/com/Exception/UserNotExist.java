package com.Exception;

public class UserNotExist extends RuntimeException {

	public UserNotExist(String msg) {
		super(msg);
	}

}
