package com.Exception;

import javax.persistence.NoResultException;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalException {

	@ExceptionHandler(value = NoResultException.class)
	public String handleNoResultException() {
		System.out.println("Username invalid");
		return "error";
	}

	@ExceptionHandler(value = UserNotExist.class)
	public String hadleUserNotExist(UserNotExist msg) {
		System.out.println(msg.getMessage());
		return "error";
	}
}
