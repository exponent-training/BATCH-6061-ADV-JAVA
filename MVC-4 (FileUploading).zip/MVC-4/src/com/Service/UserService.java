package com.Service;

import org.springframework.web.multipart.MultipartFile;

import com.Model.User;

public interface UserService {

	public void signUpUser(User user);

	public User sigInUser(String username, String password);

	public void uploadFileInService(MultipartFile file);

}
