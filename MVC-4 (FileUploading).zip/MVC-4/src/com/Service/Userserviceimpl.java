package com.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.Dao.Userdao;
import com.Exception.UserNotExist;
import com.Model.User;

@Service
public class Userserviceimpl implements UserService {

	@Autowired
	private Userdao ud;

	@Override
	public void signUpUser(User user) {

		System.out.println("I am in Service layer ::" + user);

		ud.signUpdao(user);

	}

	@Override
	public User sigInUser(String username, String password) {

		System.out.println("I am in Service layer ::" + username + " " + password);

		User user = ud.signInDao(username);

		if (user == null) {
			throw new UserNotExist("User Not Found");
		}

		if (user.getUpassword().equals(password)) {
			return user;
		} else {
			return null;
		}

	}
	
	@Override
	public void uploadFileInService(MultipartFile file) {
		
		System.out.println("I am in Service Layer");
		
		System.out.println("File Name is :: " + file.getOriginalFilename());
		
		ud.uploadFileinDao(file);
		
	}
}
