package com.Dao;

import org.springframework.web.multipart.MultipartFile;

import com.Model.User;

public interface Userdao {

	public void signUpdao(User user);

	public User signInDao(String username);

	public void uploadFileinDao(MultipartFile file);
	
}
