package com.Dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.Model.FileUpload;
import com.Model.User;

@Repository
public class Userdaoimpl implements Userdao {

	@Autowired
	private SessionFactory sf;

	@Override
	public void signUpdao(User user) {

		System.out.println("I am in Dao Layer :: " + user);

		Session session = sf.openSession();

		session.save(user);
		session.beginTransaction().commit();
		System.out.println("User saved");

		// db -persist
	}

	@Override
	public User signInDao(String username) {

		System.out.println("I am in Dao Layer :: " + username);

		Session s = sf.openSession();
		Query query = s.createQuery("from User where uname =:un");
//		List<User> allusers = query.getResultList();
//		User us = null;
//		for (User user : allusers) {
//			if (user.getUname().equals(username)) {
//				us = user;
//				break;
//			}
//		}
		query.setParameter("un", username);
		User user = (User) query.getSingleResult();
		System.out.println("My user is  : " + user);

		return user;

	}

	@Override
	public void uploadFileinDao(MultipartFile file) {

		System.out.println("I am in Dao Layer");

		Session s = sf.openSession();

		FileUpload fileu = new FileUpload();
		try {
			fileu.setFileName(file.getOriginalFilename());
			fileu.setFileData(file.getBytes());

			s.save(fileu);
			s.beginTransaction().commit();
			System.out.println("File Saved");

		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
