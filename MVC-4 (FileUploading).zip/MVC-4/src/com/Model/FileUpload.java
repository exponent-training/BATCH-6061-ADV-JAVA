package com.Model;

import java.time.LocalDateTime;
import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
public class FileUpload {

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private int fid;

	private String fileName;

	@Lob
	private byte[] fileData;

	@CreationTimestamp
	private LocalDateTime creationDate;

	@UpdateTimestamp
	private LocalDateTime updationdate;

	public int getFid() {
		return fid;
	}

	public void setFid(int fid) {
		this.fid = fid;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public byte[] getFileData() {
		return fileData;
	}

	public void setFileData(byte[] fileData) {
		this.fileData = fileData;
	}

	public LocalDateTime getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(LocalDateTime creationDate) {
		this.creationDate = creationDate;
	}

	public LocalDateTime getUpdationdate() {
		return updationdate;
	}

	public void setUpdationdate(LocalDateTime updationdate) {
		this.updationdate = updationdate;
	}

	@Override
	public String toString() {
		return "FileUpload [fid=" + fid + ", fileName=" + fileName + ", fileData=" + Arrays.toString(fileData)
				+ ", creationDate=" + creationDate + ", updationdate=" + updationdate + "]";
	}

}
